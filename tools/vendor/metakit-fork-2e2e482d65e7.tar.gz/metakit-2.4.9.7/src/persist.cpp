// persist.cpp --
// $Id$
// This is part of Metakit, the homepage is http://www.equi4.com/metakit.html

/** @file
 * Implementation of the main file management classes
 */

#include "header.h"
#include "column.h"
#include "persist.h"
#include "handler.h"
#include "store.h"
#include "field.h"
#include "marks.h"

// The datafile size above which wide marks are used, see marks.h.  The
// default leaves room for the tails below the largest 31-bit position.
t4_fpos f4_WideAbove = 0x7fffffff - 64;
t4_fpos f4_MaxFileEnd = f4_kMaxWideEnd;

/////////////////////////////////////////////////////////////////////////////

class c4_FileMark {
    enum {
        kStorageFormat = 0x4C4A,  // b0 = 'J', b1 = <4C> (on Intel)
        kReverseFormat = 0x4A4C  // b0 = <4C>, b1 = 'J'
    };

    t4_byte _data[8];

  public:
    c4_FileMark();
    c4_FileMark(t4_fpos pos_, bool flipped_, bool extend_, bool wide_ = false);
    c4_FileMark(t4_fpos pos_, int len_);

    t4_i32 Offset()const;
    t4_i32 OldOffset()const;
    t4_fpos WideOffset()const;

    bool IsHeader()const;
    bool IsWide()const;
    bool IsOldHeader()const;
    bool IsFlipped()const;
};

/////////////////////////////////////////////////////////////////////////////

c4_FileMark::c4_FileMark() {
  d4_assert(sizeof *this == 8);
}

c4_FileMark::c4_FileMark(t4_fpos pos_, bool flipped_, bool extend_, bool 
  wide_) {
  d4_assert(sizeof *this == 8);
  *(short*)_data = flipped_ ? kReverseFormat : kStorageFormat;
  _data[2] = extend_ ? 0x0A : 0x1A;
  _data[3] = 0;

  if (wide_) {
    // 6 more bits of the offset go in the last bits of the flag byte, and
    // anything beyond that is clipped, see marks.h
    t4_fpos hi = f4_High32(pos_);
    if (hi > 0x3F) {
      hi = 0x3F;
      pos_ = 0xFFFFFFFF;
    }
    _data[3] = (t4_byte)(kHeadWide | hi);
  } else
    d4_assert(pos_ >= 0 && pos_ <= 0x7fffffff);

  f4_Put32(_data + 4, pos_);
}

c4_FileMark::c4_FileMark(t4_fpos pos_, int len_) {
  d4_assert(sizeof *this == 8);
  t4_byte *p = _data;
  *p++ = kMarkTail;
  for (int j = 16; j >= 0; j -= 8)
    *p++ = (t4_byte)(len_ >> j);
  d4_assert(pos_ >= 0 && pos_ <= 0x7fffffff);
  f4_Put32(p, pos_);
}

t4_i32 c4_FileMark::Offset()const {
  t4_i32 v = 0;
  for (int i = 4; i < 8; ++i)
    v = (v << 8) + _data[i];
  return v;
}

t4_i32 c4_FileMark::OldOffset()const {
  t4_i32 v = 0;
  for (int i = 8; --i >= 4;)
    v = (v << 8) + _data[i];
  return v;
}

// the offset of a wide header, or -1 if it was clipped (or this is no such)
t4_fpos c4_FileMark::WideOffset()const {
  if (!IsWide())
    return  - 1;
  const t4_fpos hi = _data[3] &0x3F;
  const t4_fpos lo = f4_Get32(_data + 4);
  return hi == 0x3F && lo == 0xFFFFFFFF ?  - 1: f4_Join32(hi, lo);
}

bool c4_FileMark::IsWide()const {
  return (_data[3] &0xC0) == kHeadWide;
}

bool c4_FileMark::IsHeader()const {
  return (_data[0] == 'J' || _data[0] == 'L') && (_data[0] ^ _data[1]) == ('J'
    ^ 'L') && _data[2] == 0x1A;
}

bool c4_FileMark::IsOldHeader()const {
  return IsHeader() && _data[3] == 0x80;
}

bool c4_FileMark::IsFlipped()const {
  return *(short*)_data == kReverseFormat;

}

/////////////////////////////////////////////////////////////////////////////

// write a skip tail at the given position, as a wide one if so requested,
// which is followed by an extension so these are 16 bytes instead of 8
static void WriteSkipTail(c4_Strategy &strategy_, t4_fpos pos_, bool wide_) {
  if (wide_) {
    t4_byte buf[16];
    f4_WideSkipMarks(buf, pos_);
    strategy_.DataWrite(pos_, buf, sizeof buf);
  } else {
    c4_FileMark mark(pos_, 0);
    strategy_.DataWrite(pos_, &mark, sizeof mark);
  }
}

/////////////////////////////////////////////////////////////////////////////

// The allocator treats everything from this position on as free space.
// It is far beyond what the file marks can express, see SaveIt below.
#if q4_FPOS64
static const t4_fpos kEndOfSpace = (t4_fpos)1 << 62;
#else 
static const t4_fpos kEndOfSpace = 0x7fffffff;
#endif 

class c4_Allocator: public c4_FposArray {
  public:
    c4_Allocator();

    void Initialize(t4_fpos first_ = 1);
    void Assign(const c4_Allocator &other_);

    t4_fpos AllocationLimit()const;

    t4_fpos Allocate(t4_fpos len_);
    void Occupy(t4_fpos pos_, t4_fpos len_);
    void Release(t4_fpos pos_, t4_fpos len_);
    void Dump(const char *str_);
    t4_i32 FreeCounts(t4_fpos *bytes_ = 0);

  private:
    int Locate(t4_fpos pos_)const;
    void InsertPair(int i_, t4_fpos from_, t4_fpos to_);
    t4_fpos ReduceFrags(int goal_, int sHi_, int sLo_);
};

/////////////////////////////////////////////////////////////////////////////
//
//  Allocation of blocks is maintained in a separate data structure.
//  There is no allocation overhead in the allocation arena itself.
//  
//  A single vector of "walls" is maintained, sorted by position:
//  
//    * Each transition between free and allocated is a single entry.
//      The number of entries is <num-free-ranges> + <num-used-ranges>.
//    * By definition, free areas start at the positions indicated
//      by the entries on even indices. Allocated ones use odd entries.
//    * There is an extra <0,0> free slot at the very beginning. This
//      simplifies boundary conditions at the start of the arena.
//    * Position zero cannot be allocated, first slot starts at 1.
//
//  Properties of this approach:
//
//    * No allocation overhead for adjacent allocated areas. On the
//      other hand, the allocator does not know the size of used slots.
//    * Alternate function allows marking a specific range as occupied.
//    * Allocator can be initialized as either all free or all in-use.
//    * Allocation info contains only integers, it could be stored.
//    * To extend allocated slots: "occupy" extra bytes at the end.
//    * Generic: can be used for memory, disk files, and array entries.

c4_Allocator::c4_Allocator() {
  Initialize();
}

void c4_Allocator::Initialize(t4_fpos first_) {
  SetSize(0, 1000); // empty, and growing in large chunks 
  Add(0); // fake block at start
  Add(0); // ... only used to avoid merging

  // if occupied, add a tiny free slot at the end, else add entire range
  if (first_ == 0)
    first_ = kEndOfSpace;

  Add(first_); // start at a nicely aligned position
  Add(kEndOfSpace); // ... practically no limit on file size
}

void c4_Allocator::Assign(const c4_Allocator &other_) {
  // plain element copy, the base class has no safe copy constructor
  SetSize(other_.GetSize());
  for (int i = 0; i < other_.GetSize(); ++i)
    SetAt(i, other_.GetAt(i));
}

t4_fpos c4_Allocator::Allocate(t4_fpos len_) {
  // zero arg is ok, it simply returns first allocatable position   
  // the free ranges are [GetAt(i), GetAt(i+1)), compare using the size of
  // the range, since "start + len_" could overflow the 32-bit range
  for (int i = 2; i < GetSize(); i += 2)
  if (GetAt(i + 1) - GetAt(i) >= len_) {
    t4_fpos pos = GetAt(i);
    if (GetAt(i + 1) - pos > len_)
      ElementAt(i) += len_;
    else
      RemoveAt(i, 2);
    return pos;
  }

  // there is no room left, i.e. the file would exceed what can be addressed
  return  - 1;
}

void c4_Allocator::Occupy(t4_fpos pos_, t4_fpos len_) {
  d4_assert(pos_ > 0);
  // note that zero size simply checks if there is any space to extend

  int i = Locate(pos_);
  d4_assert(0 < i && i < GetSize());

  if (i % 2) {
    // allocation is not at start of free block
    d4_assert(GetAt(i - 1) < pos_);

    if (GetAt(i) == pos_ + len_)
    // allocate from end of free block
      SetAt(i, pos_);
    else
    // split free block in two
      InsertPair(i, pos_, pos_ + len_);
  } else if (GetAt(i) == pos_)
  /*
  This side of the if used to be unconditional, but that was
  incorrect if ReduceFrags gets called (which only happens with
  severely fragmented files) - there are cases when allocation
  leads to an occupy request of which the free space list knows
  nothing about because it dropped small segments.  The solution
  is to silently "allow" such allocations - fixed 29-02-2000
  Thanks to Andrew Kuchling for his help in chasing this bug.
   */
   {
    // else extend tail of allocated area
    if (GetAt(i + 1) > pos_ + len_)
      ElementAt(i) += len_;
    // move start of next free up
    else
      RemoveAt(i, 2);
    // remove this slot
  }
}

void c4_Allocator::Release(t4_fpos pos, t4_fpos len) {
  int i = Locate(pos + len);
  d4_assert(0 < i && i < GetSize());
  d4_assert(i % 2 == 0); // don't release inside a free block

  if (GetAt(i) == pos)
  // move start of next free down 
    ElementAt(i) -= len;
  else if (GetAt(i - 1) == pos)
  // move end of previous free up
    ElementAt(i - 1) += len;
  else
  // insert a new entry
    InsertPair(i, pos, pos + len);

  if (GetAt(i - 1) == GetAt(i))
  // merge if adjacent free
    RemoveAt(i - 1, 2);
}

t4_fpos c4_Allocator::AllocationLimit()const {
  d4_assert(GetSize() >= 2);

  return GetAt(GetSize() - 2);
}

int c4_Allocator::Locate(t4_fpos pos)const {
  int lo = 0, hi = GetSize() - 1;

  while (lo < hi) {
    int i = (lo + hi) / 2;
    if (pos < GetAt(i))
      hi = i - 1;
    else if (pos > GetAt(i))
      lo = i + 1;
    else
      return i;
  }

  return lo < GetSize() && pos > GetAt(lo) ? lo + 1: lo;
}

void c4_Allocator::InsertPair(int i_, t4_fpos from_, t4_fpos to_) {
  d4_assert(0 < i_);
  d4_assert(i_ < GetSize());

  d4_assert(from_ < to_);
  d4_assert(GetAt(i_ - 1) < from_);
  //!d4_assert(to_ < GetAt(i_));

  if (to_ >= GetAt(i_))
    return ;
  // ignore 2nd allocation of used area

  InsertAt(i_, from_, 2);
  SetAt(i_ + 1, to_);

  // it's ok to have arrays up to some 30000 bytes
  if (GetSize() > 7500)
    ReduceFrags(5000, 12, 6);
}

t4_fpos c4_Allocator::ReduceFrags(int goal_, int sHi_, int sLo_) {
  // drastic fail-safe measure: remove small gaps if vec gets too long
  // this will cause some lost free space but avoids array overflow
  // the lost space will most probably be re-used after the next commit

  int limit = GetSize() - 2;
  t4_fpos loss = 0;

  // go through all entries and remove gaps under the given threshold
  for (int shift = sHi_; shift >= sLo_; --shift) {
    // the threshold is a fraction of the current size of the arena
    t4_fpos threshold = AllocationLimit() >> shift;
    if (threshold == 0)
      continue;

    int n = 2;
    for (int i = n; i < limit; i += 2)
    if (GetAt(i + 1) - GetAt(i) > threshold) {
      SetAt(n++, GetAt(i));
      SetAt(n++, GetAt(i + 1));
    } else
      loss += GetAt(i + 1) - GetAt(i);

    limit = n;

    // if (GetSize() < goal_) - suboptimal, fixed 29-02-2000
    if (limit < goal_)
      break;
    // got rid of enough entries, that's enough
  }

  int n = GetSize() - 2;
  SetAt(limit++, GetAt(n++));
  SetAt(limit++, GetAt(n));
  SetSize(limit);

  return loss;
}

#if q4_CHECK
#include <stdio.h>

void c4_Allocator::Dump(const char *str_) {
  fprintf(stderr, "c4_Allocator::Dump, %d entries <%s>\n", GetSize(), str_);
  for (int i = 2; i < GetSize(); i += 2)
    fprintf(stderr, "  %10ld .. %ld\n", (long)GetAt(i - 1), (long)GetAt(i));
  fprintf(stderr, "END\n");
}

#else 

void c4_Allocator::Dump(const char *str_){}

#endif 

t4_i32 c4_Allocator::FreeCounts(t4_fpos *bytes_) {
  if (bytes_ != 0) {
    t4_fpos total = 0;
    for (int i = 2; i < GetSize() - 2; i += 2)
      total += GetAt(i + 1) - GetAt(i);
    *bytes_ = total;
  }
  return GetSize() / 2-2;
}

/////////////////////////////////////////////////////////////////////////////

class c4_Differ {
  public:
    c4_Differ(c4_Storage &storage_, bool wide_);
    ~c4_Differ();

    int NewDiffID();
    void CreateDiff(int id_, c4_Column &col_);
    t4_fpos BaseOfDiff(int id_);
    void ApplyDiff(int id_, c4_Column &col_)const;

    void GetRoot(c4_Bytes &buffer_);

    c4_Storage _storage;
    c4_View _diffs;
    c4_View _temp;

  private:
    void AddEntry(t4_i32, t4_i32, const c4_Bytes &);
    void SetLayout(bool wide_);

    // positions in a datafile of over 2 Gb do not fit the original layout,
    // for those a second int holds the high bits.  The layout of the aside
    // file does not change as long as it only refers to smaller datafiles.
    bool _wide;

    c4_ViewProp pCols; //  column info:
    c4_IntProp pOrig; //    original position (low 32 bits)
    c4_IntProp pOrigHi; //    ... and the high bits, only if _wide
    c4_ViewProp pDiff; //    difference chunks:
    c4_IntProp pKeep; //      offset
    c4_IntProp pResize; //      length
    c4_BytesProp pBytes; //      data
};

c4_Differ::c4_Differ(c4_Storage &storage_, bool wide_): _storage(storage_),
  _wide(false), pCols("_C"), pOrig("_O"), pOrigHi("_Q"), pDiff("_D"), pKeep
  ("_K"), pResize("_R"), pBytes("_B") {
  // never drop the high bits of an aside file which already has them
  const char *desc = _storage.Description("_C");
  if (desc != 0 && strstr(desc, "_Q:") != 0)
    wide_ = true;

  SetLayout(wide_);
}

void c4_Differ::SetLayout(bool wide_) {
  _wide = wide_;

  // weird names, to avoid clashing with existing ones (capitalization!)
  _diffs = _storage.GetAs(_wide ? "_C[_O:I,_Q:I,_D[_K:I,_R:I,_B:B]]":
    "_C[_O:I,_D[_K:I,_R:I,_B:B]]");
}

c4_Differ::~c4_Differ() {
  _diffs = c4_View();
}

void c4_Differ::AddEntry(t4_i32 off_, t4_i32 len_, const c4_Bytes &data_) {
  int n = _temp.GetSize();
  _temp.SetSize(n + 1);
  c4_RowRef r = _temp[n];

  pKeep(r) = (t4_i32)off_;
  pResize(r) = (t4_i32)len_;
  pBytes(r).SetData(data_);
}

int c4_Differ::NewDiffID() {
  int n = _diffs.GetSize();
  _diffs.SetSize(n + 1);
  return n;
}

void c4_Differ::CreateDiff(int id_, c4_Column &col_) {
  _temp.SetSize(0);
#if 0
  t4_i32 offset = 0;
  t4_i32 savedOff = 0;
  t4_i32 savedLen = 0;

  c4_Strategy *strat = col_.Persist() != 0 ? &col_.Strategy(): 0;

  c4_ColIter iter(col_, 0, col_.ColSize());
  while (iter.Next()) {
    const t4_byte *p = iter.BufLoad();
    if (strat != 0 && strat->_mapStart != 0 && p >= strat->_mapStart && p -
      strat->_mapStart < strat->_dataSize) {
      t4_i32 nextOff = p - strat->_mapStart;
      if (savedLen == 0)
        savedOff = nextOff;
      if (nextOff == savedOff + savedLen) {
        savedLen += iter.BufLen();
        continue;
      }

      if (savedLen > 0)
        AddEntry(savedOff, savedLen, c4_Bytes());

      savedOff = nextOff;
      savedLen = iter.BufLen();
    } else {
      AddEntry(savedOff, savedLen, c4_Bytes(p, iter.BufLen()));
      savedLen = 0;
    }

    offset += iter.BufLen();
  }

  c4_View diff = pDiff(_diffs[id_]);
  if (_temp.GetSize() != diff.GetSize() || _temp != diff)
#else 
    c4_Bytes t1;
  const t4_byte *p = col_.FetchBytes(0, col_.ColSize(), t1, false);
  AddEntry(0, 0, c4_Bytes(p, col_.ColSize()));
#endif 
  pDiff(_diffs[id_]) = _temp;

  // a position which does not fit an int is stored in two halves
  const t4_fpos pos = col_.Position();
#if q4_FPOS64
  if (!_wide && pos != (t4_fpos)(t4_i32)pos)
    SetLayout(true);
  pOrig(_diffs[id_]) = (t4_i32)(pos &0xFFFFFFFF);
  if (_wide)
    pOrigHi(_diffs[id_]) = (t4_i32)(pos >> 32);
#else 
  pOrig(_diffs[id_]) = pos;
#endif 
}

t4_fpos c4_Differ::BaseOfDiff(int id_) {
  d4_assert(0 <= id_ && id_ < _diffs.GetSize());

  const t4_i32 lo = pOrig(_diffs[id_]);
#if q4_FPOS64
  if (_wide) {
    const t4_i32 hi = pOrigHi(_diffs[id_]);
    return (t4_fpos)hi *((t4_fpos)1 << 32) + ((t4_fpos)lo &0xFFFFFFFF);
  }
#endif 
  return lo; 
}

void c4_Differ::ApplyDiff(int id_, c4_Column &col_)const {
  d4_assert(0 <= id_ && id_ < _diffs.GetSize());

  // The aside file is a datafile, which may be damaged: what it says to do
  // with the column has to fit the column, else the rest of it is not done.
  const t4_i32 want = col_.ColSize(); // this is what the size must end up as
  bool ok = true;

  c4_View diff = pDiff(_diffs[id_]);
  t4_i32 offset = 0;

  for (int n = 0; n < diff.GetSize() && ok; ++n) {
    c4_RowRef row(diff[n]);
    const t4_i32 keep = pKeep(row);
    const t4_i32 change = pResize(row);

    c4_Bytes data;
    pBytes(row).GetData(data);

    t4_i32 size = col_.ColSize();
    if (keep < 0 || keep > size - offset) {
      ok = false;
      break;
    }
    offset += keep;

    // the following code is a lot like c4_MemoRef::Modify
    if (change < 0) {
      if (change < -(size - offset)) {
        ok = false;
        break;
      }
      col_.Shrink(offset,  - change);
    } else if (change > 0) {
      if (change > f4_MaxColumnSize - size) {
        ok = false;
        break;
      }
      col_.Grow(offset, change);
    }

    if (data.Size() > col_.ColSize() - offset) {
      ok = false;
      break;
    }

    col_.StoreBytes(offset, data);
    offset += data.Size();
  }

  if (!ok) {
    // keep what is right, and make sure that the column is as large as it was
    // said to be, with zero where there is nothing: all else would be reading
    // beyond it
    t4_i32 size = col_.ColSize();
    if (size > want)
      col_.Shrink(want, size - want);
    else if (size < want) {
      col_.Grow(size, want - size);
      t4_byte zeros[256];
      memset(zeros, 0, sizeof zeros);
      for (t4_i32 at = size; at < want; at += sizeof zeros) {
        int len = want - at < (t4_i32)sizeof zeros ? (int)(want - at): (int)
          sizeof zeros;
        col_.StoreBytes(at, c4_Bytes(zeros, len));
      }
    }

    if (col_.Persist() != 0)
      col_.Persist()->SetDamaged();
  }
}

void c4_Differ::GetRoot(c4_Bytes &buffer_) {
  int last = _diffs.GetSize() - 1;
  if (last >= 0) {
    c4_Bytes temp;
    c4_View diff = pDiff(_diffs[last]);
    if (diff.GetSize() > 0)
      pBytes(diff[0]).GetData(buffer_);
  }
}

/////////////////////////////////////////////////////////////////////////////

c4_SaveContext::c4_SaveContext(c4_Strategy &strategy_, bool fullScan_, int
  mode_, c4_Differ *differ_, c4_Allocator *space_): _strategy(strategy_), _walk
  (0), _differ(differ_), _space(space_), _cleanup(0), _nextSpace(0), _preflight
  (true), _fullScan(fullScan_), _mode(mode_), _nextPosIndex(0), _bufPtr(_buffer)
  , _curr(_buffer), _limit(_buffer) {
  if (_space == 0)
    _space = _cleanup = d4_new c4_Allocator;

  _nextSpace = _mode == 1 ? d4_new c4_Allocator: _space;
}

c4_SaveContext::~c4_SaveContext() {
  delete _cleanup;
  if (_nextSpace != _space)
    delete _nextSpace;
}

bool c4_SaveContext::IsFlipped()const {
  return _strategy._bytesFlipped;
}

bool c4_SaveContext::Serializing()const {
  return _fullScan;
}

void c4_SaveContext::AllocDump(const char *str_, bool next_) {
  c4_Allocator *ap = next_ ? _nextSpace : _space;
  if (ap != 0)
    ap->Dump(str_);
}

void c4_SaveContext::FlushBuffer() {
  int n = _curr - _bufPtr;
  if (_walk != 0 && n > 0) {
    t4_i32 end = _walk->ColSize();
    _walk->Grow(end, n);
    _walk->StoreBytes(end, c4_Bytes(_bufPtr, n));
  }

  _curr = _bufPtr = _buffer;
  _limit = _buffer + sizeof _buffer;
}

c4_Column *c4_SaveContext::SetWalkBuffer(c4_Column *col_) {
  FlushBuffer();

  c4_Column *prev = _walk;
  _walk = col_;
  return prev;
}

void c4_SaveContext::Write(const void *buf_, int len_) {
  // use buffering if possible
  if (_curr + len_ <= _limit) {
    memcpy(_curr, buf_, len_);
    _curr += len_;
  } else {
    FlushBuffer();
    _bufPtr = (t4_byte*)buf_; // also loses const
    _curr = _limit = _bufPtr + len_;
    FlushBuffer();
  }
}

void c4_SaveContext::StoreValue(t4_i32 v_) {
  if (_walk == 0)
    return ;

  if (_curr + 10 >= _limit)
    FlushBuffer();

  d4_assert(_curr + 10 < _limit);
  c4_Column::PushValue(_curr, v_);
}

void c4_SaveContext::StoreValue64(t4_fpos v_) {
  if (_walk == 0)
    return ;

  if (_curr + 10 >= _limit)
    FlushBuffer();

  d4_assert(_curr + 10 < _limit);
  c4_Column::PushValue64(_curr, v_);
}

void c4_SaveContext::SaveIt(c4_HandlerSeq &root_, c4_Allocator **spacePtr_,
  c4_Bytes &rootWalk_) {
  d4_assert(_space != 0);

  const t4_fpos size = _strategy.FileSize();
  if (_strategy._failure != 0)
    return ;

  const t4_fpos end = _fullScan ? 0 : size - _strategy._baseOffset;
  int oldTails = kStdTailSize; // the size of the tails now at the end

  // Where the last complete commit ended, if that is not at the end of the
  // file, which is so after an interrupted commit.  The commit which is made
  // now goes behind what remains of that one.  The way back to it from the
  // header (see RecoverEnd) has to be repaired to lead there, or else it is
  // lost again if this commit gets interrupted too.  If there is no complete
  // commit at all, it is the header itself which has to be repaired.
  const t4_fpos lastEnd = _strategy._lastEnd >= 0 ? _strategy._lastEnd -
    _strategy._baseOffset:  - 1;
  const bool noCommit = !_fullScan && end > 0 && _strategy._hasHeader &&
    lastEnd < 0;
  const bool repairChain = !_fullScan && _mode == 2 && end > 0 && lastEnd >= 8
    && lastEnd + 8 <= end;

  if (_differ == 0) {
    if (_mode != 1)
      _space->Initialize();

    // don't allocate anything inside the file in extend mode
    if (_mode == 2 && end > 0) {
      _space->Occupy(1, end - 1);
      _nextSpace->Occupy(1, end - 1);
    }

    // the header is always reserved
    _space->Occupy(1, 7);
    _nextSpace->Occupy(1, 7);

    if (end > 0) {
      // The tails of the file as it is now are wide or standard ones, or
      // there are none: after an interrupted commit, the file was opened
      // by RecoverEnd and ends with the remains of that commit.  The tails
      // which count are then somewhere inside, and nothing at the end may
      // be taken for them.
      //
      // Loading found out which it is, and what looks like tails is not to
      // be trusted if it did not: a datafile which is cut at the wrong place
      // ends with bytes which can look like anything.  Strategies which have
      // not loaded anything (that is, not by EndOfData) are left to guess.
      t4_byte last[8];
      oldTails = 0;
      const bool known = _strategy._lastEnd >= 0 || _strategy._hasHeader;
      if ((!known || lastEnd == end) && _strategy.DataRead(end - 8, last,
        sizeof last) == sizeof last) {
        if (last[0] == kMarkWideCommit)
          oldTails = kWideTailSize;
        else if (last[0] == kMarkTail && (last[1] | last[2] | last[3]) != 0)
          oldTails = kStdTailSize;
      }

      if (oldTails > 0) {
        d4_assert(end >= oldTails);
        _space->Occupy(end - oldTails, oldTails);
        _nextSpace->Occupy(end - oldTails, oldTails);
      } else if (lastEnd >= 24 && lastEnd + 8 <= end) {
        // The tails of the last complete commit are not at the end, there
        // are remains of one which was interrupted behind them.  Nothing may
        // be put over them, or if this commit gets interrupted as well, that
        // last complete commit would not be found any more.
        int lastTails = kStdTailSize;
        if (_strategy.DataRead(lastEnd - 8, last, sizeof last) == sizeof last &&
          last[0] == kMarkWideCommit)
          lastTails = kWideTailSize;

        _space->Occupy(lastEnd - lastTails, lastTails);
        _nextSpace->Occupy(lastEnd - lastTails, lastTails);
        _space->Occupy(lastEnd, 8);
        _nextSpace->Occupy(lastEnd, 8);
      }
      _space->Occupy(end, 8);
      _nextSpace->Occupy(end, 8);
    }
  }

  //AllocDump("a1", false);
  //AllocDump("a2", true);

  // The first pass allocates from the space of the previous commit, which
  // lives on in the c4_Persist object in mode 1. Keep a copy, so a commit
  // which fails before anything was written leaves that state untouched.
  // Without this, the next commit would start from a damaged free list.
  c4_Allocator spaceBackup;
  const bool restorable = _differ == 0 && _space != _nextSpace;
  if (restorable)
    spaceBackup.Assign(*_space);

  // first pass allocates columns and constructs shallow walks
  c4_Column walk(root_.Persist());
  SetWalkBuffer(&walk);
  CommitSequence(root_, true);
  SetWalkBuffer(0);
  CommitColumn(walk);

  t4_fpos limit = _nextSpace->AllocationLimit();
  d4_assert(limit >= 8 || _differ != 0 || _strategy._failure != 0);

  // 2006-01-12 #2: catch file size exceeding what the marks can express, which
  // is flagged either by the allocator running out of room or by the limit
  // leaving the range in which the file marks (and the arithmetic below) are
  // safe.  The length of the root must fit in 24 bits, which is a limit too.
  if (_strategy._failure != 0 || limit < 0 || limit > f4_MaxFileEnd ||
    (_differ == 0 && walk.ColSize() > 0xFFFFFF)) {
    if (_strategy._failure == 0)
      _strategy._failure =  - 1; // unusual non-zero value flags this case
    if (restorable)
      _space->Assign(spaceBackup);
    return ;
  }

  c4_Bytes tempWalk;
  walk.FetchBytes(0, walk.ColSize(), tempWalk, true);

  bool changed = _fullScan || tempWalk != rootWalk_;

  rootWalk_ = c4_Bytes(tempWalk.Contents(), tempWalk.Size(), true);

  _preflight = false;

  // special-case to avoid saving data if file is logically empty
  // in that case, the data is 0x80 0x81 0x80 (plus the header)
  if (!_fullScan && limit <= 11 && _differ == 0) {
    _space->Initialize();
    _nextSpace->Initialize();
    changed = false;
  }

  if (!changed)
    return ;

  //AllocDump("b1", false);
  //AllocDump("b2", true);

  if (_differ != 0) {
    int n = _differ->NewDiffID();
    _differ->CreateDiff(n, walk);
    return ;
  }

  d4_assert(_mode != 0 || _fullScan);

  // In the default mode, the header leads to the last commit, which is how it
  // is found if the datafile gets interrupted in a later commit (RecoverEnd).
  // Yet if a commit was interrupted between its last tail and its header, the
  // header leads to the commit before it.  That one is going to be overwritten
  // by this commit, so before anything is written, make the header right.
  if (_mode == 1 && !_fullScan && end > 0 && lastEnd >= 24 && lastEnd <= end) {
    t4_byte hm[8], lm[8];
    if (_strategy.DataRead(0, hm, sizeof hm) == sizeof hm &&
      _strategy.DataRead(lastEnd - 8, lm, sizeof lm) == sizeof lm) {
      const bool lastWide = lm[0] == kMarkWideCommit;
      t4_fpos at = f4_Get32(hm + 4);
      if (hm[3] &kHeadWide)
        at = f4_Join32(hm[3] &0x3F, at);

      if (at != lastEnd) {
        c4_FileMark head(lastEnd, _strategy._bytesFlipped, false, lastWide);
        _strategy.DataWrite(0, &head, sizeof head);
      }
    }
  }

  // this is the place where writing may start

  // Files which grow too large for 31-bit positions get wide marks, and so
  // do files which already have them.  The tails of such files take more
  // space, but all the logic is the same, except for in-place commits.
#if q4_FPOS64
  const bool wide = oldTails == kWideTailSize || limit > f4_WideAbove;
#else 
  const bool wide = false;
#endif 
  const int tails = wide ? kWideTailSize : kStdTailSize;

  // figure out where the new file ends and write a skip tail there
  t4_fpos end0 = end;

  // True if the file need not be extended due to internal free space.  This
  // overwrites the commit tail, which can only be done safely in a single
  // write of 8 bytes, so wide files do not do this, they always append.
  bool inPlace = !wide && oldTails == kStdTailSize && end0 == limit - 8;
  if (inPlace) {
    d4_assert(!_fullScan);
    _space->Release(end0, 8);
    _nextSpace->Release(end0, 8);
    end0 -= kStdTailSize; // overwrite existing tail markers
  } else {
    c4_FileMark head(limit + tails - end, _strategy._bytesFlipped, end > 0,
      wide);

    // The header of a new datafile goes first.  Otherwise, if this commit gets
    // interrupted right after the end marker below, what is in the file does
    // not start like a datafile, and the next time it is taken for something
    // else, to which a datafile gets added, which cannot be found any more if
    // that gets interrupted.  The bytes which end up in the file are the same.
    if (end == 0)
      _strategy.DataWrite(end, &head, sizeof head);

    /* 18-11-2005 write new end marker and flush it before *anything* else! */
    if (!_fullScan && end0 < limit) {
      WriteSkipTail(_strategy, limit, wide);
      _strategy.DataCommit(0);
      if (_strategy._failure != 0)
        return ;
    }

    if (end > 0)
      _strategy.DataWrite(end, &head, sizeof head);

    if (end0 < limit)
      end0 = limit;
    // create a gap
  }

  // end1 is where the commit tail goes, which is the last 8 bytes
  t4_fpos end1 = end0 + tails - 8;
  t4_fpos end2 = end1 + 8;

  if (!_fullScan && !inPlace) {
    WriteSkipTail(_strategy, end0, wide);
#if q4_WIN32
    /* March 8, 2002
     * On at least NT4 with NTFS, extending a file can cause it to be
     * rounded up further than expected.  To prevent creating a bad
     * file (since the file does then not end with a marker), the
     * workaround it so simply accept the new end instead and rewrite.
     * Note that between these two writes, the file is in a bad state.
     */
    t4_fpos realend = _strategy.FileSize() - _strategy._baseOffset;
    if (realend > end1) {
      end0 = limit = realend - (end1 - end0);
      end1 = realend;
      end2 = realend + 8;
      WriteSkipTail(_strategy, end0, wide);
    }
#endif 
    d4_assert(_strategy.FileSize() == _strategy._baseOffset + end1);
  }

  _space->Occupy(end0, tails);
  _nextSpace->Occupy(end0, tails);

  // strategy.DataCommit(0); // may be needed, need more info on how FS's work
  // but this would need more work, since we can't adjust file-mapping here

  // second pass saves the columns and structure to disk
  CommitSequence(root_, true); // writes changed columns
  CommitColumn(walk);

  //! d4_assert(_curr == 0);
  d4_assert(_nextPosIndex == _newPositions.GetSize());

  if (_fullScan) {
    if (wide) {
      // written in one go, since streams only allow sequential writing
      t4_byte buf[kWideTailSize];
      f4_WideSkipMarks(buf, limit);
      f4_WideCommitMarks(buf + 8, limit, limit - walk.ColSize(), walk.ColSize
        ());
      _strategy.DataWrite(_strategy.FileSize() - _strategy._baseOffset, buf,
        sizeof buf);
    } else {
      c4_FileMark mark1(limit, 0);
      _strategy.DataWrite(_strategy.FileSize() - _strategy._baseOffset,  &mark1,
        sizeof mark1);

      c4_FileMark mark2(limit - walk.ColSize(), walk.ColSize());
      _strategy.DataWrite(_strategy.FileSize() - _strategy._baseOffset,  &mark2,
        sizeof mark2);
    }

    return ;
  }

  if (inPlace)
    d4_assert(_strategy.FileSize() == _strategy._baseOffset + end2);
  else {
    // make sure the allocated size hasn't changed
    d4_assert(_nextSpace->AllocationLimit() == limit + tails);
    d4_assert(end0 >= limit);
    d4_assert(_strategy.FileSize() - _strategy._baseOffset == end1);
  }

  if (walk.Position() == 0 || _strategy._failure != 0)
    return ;

  // What is left of an interrupted commit ends with a mark which says that
  // another commit goes up to there, which now is this one (see RecoverEnd).
  // And the header of a datafile which has no commit does not lead anywhere.
  // These come before the commit tail, since if they were done after it, an
  // interruption in between would leave a datafile which looks fine, but in
  // which the way back to this commit is still broken.  If this commit does
  // not get completed they are of no consequence: what they lead to is not
  // a commit then, and the way back stops where it did.
  if (repairChain) {
    c4_FileMark fix(end2 - lastEnd, _strategy._bytesFlipped, true, wide);
    _strategy.DataWrite(lastEnd, &fix, sizeof fix);
  }
  if (noCommit) {
    c4_FileMark head(end2, _strategy._bytesFlipped, false, wide);
    _strategy.DataWrite(0, &head, sizeof head);
  }

  _strategy.DataCommit(0);

  if (wide) {
    // the extension is rewritten as well, now that the root is known
    t4_byte buf[16];
    f4_WideCommitMarks(buf, end0, walk.Position(), walk.ColSize());
    _strategy.DataWrite(end1 - 8, buf, sizeof buf);
  } else {
    c4_FileMark mark2(walk.Position(), walk.ColSize());
    _strategy.DataWrite(end1, &mark2, sizeof mark2);
  }
  d4_assert(_strategy.FileSize() - _strategy._baseOffset == end2);

  // do not alter the file header in extend mode, unless it is new (a header
  // of a datafile which has no commit was already done, above)
  if (!_fullScan && (_mode == 1 || end == 0)) {
    _strategy.DataCommit(0);

    c4_FileMark head(end2, _strategy._bytesFlipped, false, wide);
    d4_assert(head.IsHeader());
    _strategy.DataWrite(0, &head, sizeof head);

    // if the file became smaller, we could shrink it
    if (limit + tails < end0) {
      /*
      Not yet, this depends on the strategy class being able to truncate, but
      there is no way to find out whether it does (the solution is to write tail
      markers in such a way that the file won't grow unnecessarily if it doesn't).

      The logic will probably be:

       * write new skip + commit "tails" at limit (no visible effect on file)
       * overwrite commit tail at end  with a skip to this new one (equivalent)
       * replace header with one pointing to that internal new one (equivalent)
       * flush (now the file is valid both truncated and not-yet-truncated

      end = limit;
       */
    }
  }

  // if using memory mapped files, make sure the map is no longer in use
  if (_strategy._mapStart != 0)
    root_.UnmappedAll();

  // commit and tell strategy object what the new file size is, this
  // may be smaller now, if old data at the end is no longer referenced
  _strategy.DataCommit(end2);

  d4_assert(_strategy.FileSize() - _strategy._baseOffset == end2);

  // this is where the datafile ends now, with a commit which is complete
  _strategy._lastEnd = end2 + _strategy._baseOffset;
  _strategy._hasHeader = false;

  if (spacePtr_ != 0 && _space != _nextSpace) {
    d4_assert(*spacePtr_ == _space);
    delete  *spacePtr_;
    *spacePtr_ = _nextSpace;
    _nextSpace = 0;
  }
}

bool c4_SaveContext::CommitColumn(c4_Column &col_) {
  // once the first pass has failed, nothing more can be allocated
  if (_preflight && _strategy._failure != 0)
    return false;

  bool changed = col_.IsDirty() || _fullScan;

  t4_i32 sz = col_.ColSize();
  StoreValue(sz);
  if (sz > 0) {
    t4_fpos pos = col_.Position();

    if (_differ) {
      if (changed) {
        int n = pos < 0 ? ~pos: _differ->NewDiffID();
        _differ->CreateDiff(n, col_);

        d4_assert(n >= 0);
        pos = ~n;
      }
    } else if (_preflight) {
      if (changed) {
        pos = _space->Allocate(sz);
        if (pos < 0) {
          // out of address space, the commit will be refused by SaveIt
          _strategy._failure =  - 1;
          return changed;
        }
      }

      _nextSpace->Occupy(pos, sz);
      _newPositions.Add(pos);
    } else {
      pos = _newPositions.GetAt(_nextPosIndex++);

      if (changed)
        col_.SaveNow(_strategy, pos);

      if (!_fullScan)
        col_.SetLocation(pos, sz);
    }

    StoreValue64(pos);
  }

  return changed;
}

void c4_SaveContext::CommitSequence(c4_HandlerSeq &seq_, bool selfDesc_) {
  StoreValue(0); // sias prefix

  if (selfDesc_) {
    c4_String desc = seq_.Description();
    int k = desc.GetLength();
    StoreValue(k);
    Write((const char*)desc, k);
  }

  StoreValue(seq_.NumRows());
  if (seq_.NumRows() > 0)
    for (int i = 0; i < seq_.NumFields(); ++i)
      seq_.NthHandler(i).Commit(*this);
}

/////////////////////////////////////////////////////////////////////////////

// used for on-the-fly conversion of old-format datafiles
t4_byte *_oldBuf;
const t4_byte *_oldCurr;
const t4_byte *_oldLimit;
t4_i32 _oldSeek;


c4_Persist::c4_Persist(c4_Strategy &strategy_, bool owned_, int mode_): _space
  (0), _strategy(strategy_), _root(0), _differ(0), _fCommit(0), _mode(mode_),
  _owned(owned_), _tainted(false), _damaged(false), _knownLimit(0), _oldBuf(0), _oldCurr(0), _oldLimit(0), _oldSeek
  ( - 1) {
  if (_mode == 1)
    _space = d4_new c4_Allocator;
}

c4_Persist::~c4_Persist() {
  delete _differ;

  if (_owned) {
    if (_root != 0)
      _root->UnmappedAll();
    delete  &_strategy;
  }

  delete _space;

  if (_oldBuf != 0)
    delete [] _oldBuf;
}

c4_HandlerSeq &c4_Persist::Root()const {
  d4_assert(_root != 0);
  return  *_root;
}

void c4_Persist::SetRoot(c4_HandlerSeq *root_) {
  d4_assert(_root == 0);
  _root = root_;
}

c4_Strategy &c4_Persist::Strategy()const {
  return _strategy;
}

bool c4_Persist::AutoCommit(bool flag_) {
  bool prev = _fCommit != 0;
  if (flag_)
    _fCommit = &c4_Persist::Commit;
  else
    _fCommit = 0;
  return prev;
}

void c4_Persist::DoAutoCommit() {
  if (_fCommit != 0)
    (this->*_fCommit)(false);
}

bool c4_Persist::SetAside(c4_Storage &aside_) {
  delete _differ;
  // files beyond 2 Gb need the wider layout for positions in the aside file
  _differ = d4_new c4_Differ(aside_, _strategy.FileSize() > 0x7fffffff);
  Rollback(false);
  return true; //! true if the generation matches
}

c4_Storage *c4_Persist::GetAside()const {
  return _differ != 0 ? &_differ->_storage: 0;
}

void c4_Persist::Taint() {
  _tainted = true;
}

bool c4_Persist::IsTainted()const {
  return _tainted;
}

void c4_Persist::SetDamaged() {
  _damaged = true;
}

bool c4_Persist::IsDamaged()const {
  return _damaged;
}

bool c4_Persist::Commit(bool full_) {
  // 1-Mar-1999, new semantics! return success status of commits
  _strategy._failure = 0;

  // after a column was refused to grow, whatever was in progress was left
  // half done, so nothing may be committed until that has been rolled back
  if (_tainted) {
    _strategy._failure =  - 2;
    return false;
  }

  if (!_strategy.IsValid())
    return false;

  if (_mode == 0 && (_differ == 0 || full_))
  // can't commit to r/o file
    return false;
  // note that _strategy._failure is *zero* in this case

  c4_SaveContext ar(_strategy, false, _mode, full_ ? 0 : _differ, _space);

  // get rid of temp properties which still use the datafile
  if (_mode == 1)
    _root->DetachFromStorage(false);

  // 30-3-2001: moved down, fixes "crash every 2nd call of mkdemo/dbg"
  ar.SaveIt(*_root, &_space, _rootWalk);
  return _strategy._failure == 0;
}

bool c4_Persist::Rollback(bool full_) {
  // like Commit, start with a clean slate: a stale failure code left by an
  // earlier failed commit would make LoadAll() skip loading and yield an
  // empty database
  _strategy._failure = 0;
  _tainted = false;
  _damaged = false; // it is found again, if it still is

  _root->DetachFromParent();
  _root->DetachFromStorage(true);
  _root = 0;

  if (_space != 0)
    _space->Initialize();

  c4_HandlerSeq *seq = d4_new c4_HandlerSeq(this);
  seq->DefineRoot();
  SetRoot(seq);

  if (full_) {
    delete _differ;
    _differ = 0;
  }

  LoadAll();

  return _strategy._failure == 0;
}

bool c4_Persist::LoadIt(c4_Column &walk_) {
  t4_fpos limit = _strategy.FileSize();
  _knownLimit = limit - _strategy._baseOffset;
  if (_strategy._failure != 0)
    return false;

  if (_strategy.EndOfData(limit) < 0) {
    // A file which starts with a header has had its first commit interrupted,
    // so it is the datafile which is going to be written, from the start.  If
    // there is something else then the datafile goes behind it.
    if (!_strategy._hasHeader)
      _strategy.SetBase(limit);
    d4_assert(_strategy._failure == 0); // file is ok, but empty
    return false;
  }

  if (_strategy._rootLen > 0) {
    // the root is somewhere in the datafile, else this is not one to use
    if (_strategy._rootPos <= 0 || _strategy._rootPos + _strategy._rootLen >
      limit - _strategy._baseOffset) {
      _damaged = true;
      return false;
    }
    walk_.SetLocation(_strategy._rootPos, _strategy._rootLen);
  }

  // if the file size has increased, we must remap
  if (_strategy._mapStart != 0 && _strategy.FileSize() > _strategy._baseOffset 
    + _strategy._dataSize)
    _strategy.ResetFileMapping();

  return true;
}

void c4_Persist::LoadAll() {
  c4_Column walk(this);
  if (!LoadIt(walk))
    return ;

  if (_strategy._rootLen < 0) {
    _oldSeek = _strategy._rootPos;
    _oldBuf = d4_new t4_byte[512];
    _oldCurr = _oldLimit = _oldBuf;

    t4_i32 n = FetchOldValue();
    d4_assert(n == 0);
    n = FetchOldValue();
    d4_assert(n > 0);

    c4_Bytes temp;
    t4_byte *buf = temp.SetBuffer(n);
    d4_dbgdef(int n2 = )OldRead(buf, n);
    d4_assert(n2 == n);

    c4_String s = "[" + c4_String((const char*)buf, n) + "]";
    const char *desc = s;

    c4_Field *f = d4_new c4_Field(desc);
    d4_assert(! *desc);

    //?_root->DefineRoot();
    _root->Restructure(*f, false);

    _root->OldPrepare();

    // don't touch data inside while converting the file
    if (_strategy.FileSize() >= 0)
      OccupySpace(1, _strategy.FileSize());
  } else {
    walk.FetchBytes(0, walk.ColSize(), _rootWalk, true);
    if (_differ)
      _differ->GetRoot(_rootWalk);

    // 2006-08-01: maintain stable-storage space usage on re-open
    OccupySpace(_strategy._rootPos, _strategy._rootLen);

    // define and fill the root table 
    // (the structure comes from the datafile, which may be damaged: if it
    // is, then nothing is used of it, see c4_WalkGuard)
    const t4_byte *ptr = _rootWalk.Contents();
    {
      c4_WalkGuard guard(ptr + _rootWalk.Size(), true);
      _root->Prepare(&ptr, true);

      if (!c4_WalkGuard::Bad() && ptr != _rootWalk.Contents() + _rootWalk.Size
        ())
        c4_WalkGuard::Fail(); // there is more than there should be

      if (c4_WalkGuard::Bad()) {
        _damaged = true;

        c4_HandlerSeq *old = _root;
        old->DetachFromParent();
        old->DetachFromStorage(true);
        _root = 0;

        c4_HandlerSeq *seq = d4_new c4_HandlerSeq(this);
        seq->DefineRoot();
        SetRoot(seq);

        // gone now, unless a view still has it (as a storage does at first)
        old->IncRef();
        old->DecRef();
      }
    }
  }
}

t4_i32 c4_Persist::FetchOldValue() {
  d4_assert(_oldSeek >= 0);

  if (_oldCurr == _oldLimit) {
    int n = OldRead(_oldBuf, 500);
    _oldLimit = _oldCurr + n;
    _oldBuf[n] = 0x80; // to force end
  }

  const t4_byte *p = _oldCurr;
  t4_i32 value = c4_Column::PullValue(p);

  if (p > _oldLimit) {
    int k = _oldLimit - _oldCurr;
    d4_assert(0 < k && k < 10);
    memcpy(_oldBuf, _oldCurr, k);

    int n = OldRead(_oldBuf + k, 500);
    _oldCurr = _oldBuf + k;
    _oldLimit = _oldCurr + n;
    _oldBuf[n + k] = 0x80; // to force end

    p = _oldCurr;
    value = c4_Column::PullValue(p);
    d4_assert(p <= _oldLimit);
  }

  _oldCurr = p;
  return value;
}

void c4_Persist::FetchOldLocation(c4_Column &col_) {
  d4_assert(_oldSeek >= 0);

  t4_i32 sz = FetchOldValue();
  if (sz > 0)
    col_.SetLocation(FetchOldValue(), sz);
}

// the free space as pairs of positions (see c4_Allocator), if tracked at all
const c4_FposArray *c4_Persist::SpaceMap()const {
  return _space;
}

t4_i32 c4_Persist::FreeBytes(t4_fpos *bytes_) {
  return _space == 0 ?  - 1: _space->FreeCounts(bytes_);
}

int c4_Persist::OldRead(t4_byte *buf_, int len_) {
  d4_assert(_oldSeek >= 0);

  t4_i32 newSeek = _oldSeek + _oldCurr - _oldLimit;
  int n = _strategy.DataRead(newSeek, buf_, len_);
  d4_assert(n > 0);
  _oldSeek = newSeek + n;
  _oldCurr = _oldLimit = _oldBuf;
  return n;
}

c4_HandlerSeq *c4_Persist::Load(c4_Stream *stream_) {
  d4_assert(stream_ != 0);

  c4_FileMark head;
  if (stream_->Read(&head, sizeof head) != sizeof head || !head.IsHeader())
    return 0;
  // no data in file

  //_oldStyle = head._data[3] == 0x80;
  d4_assert(!head.IsOldHeader());

  // the data is loaded into memory, which also limits the size it can have
  t4_fpos limit = head.IsWide() ? head.WideOffset(): head.Offset();
  if (limit < 0 || limit > 0x7fffffff)
    return 0;

  c4_StreamStrategy *strat = d4_new c4_StreamStrategy(limit);
  strat->_bytesFlipped = head.IsFlipped();
  strat->DataWrite(0, &head, sizeof head);

  for (t4_fpos got = sizeof head; got < limit;) {
    char buffer[4096];
    int n = stream_->Read(buffer, sizeof buffer);
    if (n <= 0) {
      // the stream is shorter than its header says
      delete strat;
      return 0;
    }
    strat->DataWrite(got, buffer, n);
    got += n;
  }

  c4_Persist *pers = d4_new c4_Persist(*strat, true, 0);
  c4_HandlerSeq *seq = d4_new c4_HandlerSeq(pers);
  seq->DefineRoot();
  pers->SetRoot(seq);

  bool ok = false;
  {
    c4_Column walk(pers);
    if (pers->LoadIt(walk)) {
      c4_Bytes tempWalk;
      walk.FetchBytes(0, walk.ColSize(), tempWalk, true);

      // the structure comes from a stream which may be damaged, see
      // c4_WalkGuard: it is not used at all if it is
      const t4_byte *ptr = tempWalk.Contents();
      c4_WalkGuard guard(ptr + tempWalk.Size(), true);
      seq->Prepare(&ptr, true);
      ok = !c4_WalkGuard::Bad() && ptr == tempWalk.Contents() + tempWalk.Size();
    }
  }

  if (!ok) {
    seq->IncRef();
    seq->DecRef(); // a funny way to delete
    return 0;
  }

  return seq;
}

void c4_Persist::Save(c4_Stream *stream_, c4_HandlerSeq &root_) {
  d4_assert(stream_ != 0);

  c4_StreamStrategy strat(stream_);

  // 31-01-2002: streaming must adopt byte order of origin datafile
  c4_Persist *p = root_.Persist();
  if (p != 0)
    strat._bytesFlipped = p->Strategy()._bytesFlipped;

  c4_SaveContext ar(strat, true, 0, 0, 0);
  c4_Bytes tempWalk;
  ar.SaveIt(root_, 0, tempWalk);
}

bool c4_Persist::IsLocationOk(t4_fpos pos_, t4_fpos size_) {
  if (size_ < 0)
    return false;

  // (the datafile can only have grown since last looked at)
  if (pos_ < 0 || pos_ + size_ > _knownLimit)
    _knownLimit = _strategy.FileSize() - _strategy._baseOffset;

  if (pos_ < 0) {
    // Data which is in the aside file: this needs one, and an id in it.  The
    // size is the one after the changes, so only the start of what they are
    // applied to can be looked at (it is nothing if the column is new).
    t4_fpos id = ~pos_;
    if (_differ == 0 || id >= _differ->_diffs.GetSize())
      return false;

    pos_ = _differ->BaseOfDiff((int)id);
    return pos_ >= 0 && pos_ <= _knownLimit;
  }

  return pos_ > 0 && pos_ + size_ <= _knownLimit;
}

t4_fpos c4_Persist::LookupAside(int id_) {
  d4_assert(_differ != 0);

  return _differ->BaseOfDiff(id_);
}

void c4_Persist::ApplyAside(int id_, c4_Column &col_) {
  d4_assert(_differ != 0);

  _differ->ApplyDiff(id_, col_);
}

void c4_Persist::OccupySpace(t4_fpos pos_, t4_fpos len_) {
  d4_assert(_mode != 1 || _space != 0);

  if (_space != 0)
    _space->Occupy(pos_, len_);
}

/////////////////////////////////////////////////////////////////////////////
